const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["_astro/terminbuch.D7DG0jp5.js","_astro/stufe.C6QST9tR.js"])))=>i.map(i=>d[i]);
import{t as e}from"./preload-helper.DHhhL8Zf.js";var t={wochentage:[1,2,3,4,5],zeiten:[`09:00`,`10:30`,`13:00`,`14:30`,`16:00`],vorlaufTage:1,monateVoraus:3,gespraechsarten:[`Telefon`,`Video`,`Persönlich vor Ort`]},n=[`Januar`,`Februar`,`März`,`April`,`Mai`,`Juni`,`Juli`,`August`,`September`,`Oktober`,`November`,`Dezember`],r=[`Sonntag`,`Montag`,`Dienstag`,`Mittwoch`,`Donnerstag`,`Freitag`,`Samstag`],i=`#version 300 es
in vec2 a;
void main() { gl_Position = vec4(a, 0.0, 1.0); }`,a=`#version 300 es
precision highp float;
out vec4 farbe;
uniform sampler2D uFoto;
uniform vec2 uRes;       // Zeichenfläche in Pixeln
uniform vec4 uAbb;       // Lage des Fotos auf dem Bildschirm: x,y oben links, Breite, Höhe (0…1 des Bildschirms)
uniform float uZeit;     // Sekunden
uniform float uTag;      // 0 = Mittag … 1 = Nacht (Scrollfortschritt)
uniform vec2 uMaus;      // -1 … 1, für leichte Tiefe
uniform float uBlitz;    // Helligkeit des Blitzes 0 … 1
uniform vec2 uBolt[8];   // Blitz-Verlauf (Bildkoordinaten)
uniform vec4 uStern;     // Sternschnuppe: Start xy, Richtung xy (Bildkoordinaten)
uniform float uSternT;   // Fortschritt 0 … 1, außerhalb: aus

const float IA = 2000.0 / 1068.0; // Seitenverhältnis des Fotos

float hash(vec2 p) { p = fract(p * vec2(123.34, 456.21)); p += dot(p, p + 45.32); return fract(p.x * p.y); }
float rausch(vec2 p) {
  vec2 i = floor(p), f = fract(p);
  vec2 u = f * f * (3.0 - 2.0 * f);
  return mix(mix(hash(i), hash(i + vec2(1, 0)), u.x), mix(hash(i + vec2(0, 1)), hash(i + vec2(1, 1)), u.x), u.y);
}
float fbm(vec2 p) {
  float s = 0.0, a = 0.5;
  for (int i = 0; i < 4; i++) { s += a * rausch(p); p = p * 2.03 + 17.1; a *= 0.5; }
  return s / 0.9375;
}
float strecke(vec2 p, vec2 a, vec2 b) {
  vec2 pa = p - a, ba = b - a;
  float h = clamp(dot(pa, ba) / dot(ba, ba), 0.0, 1.0);
  return length(pa - ba * h);
}

/* Horizont: Meerlinie links, Bergkamm rechts. */
float horizont(float x) {
  float links = 0.400 - 0.004 * smoothstep(0.45, 0.6, x);
  float rechts = mix(0.385, 0.250, smoothstep(0.60, 1.00, x));
  return mix(links, rechts, smoothstep(0.55, 0.72, x));
}
/* 1 am Himmel, 0 an Land und Meer (weich, damit keine Treppen entstehen). */
float himmelMaske(vec2 b) { return smoothstep(horizont(b.x) + 0.003, horizont(b.x) - 0.003, b.y); }
/* Meer links vor der Küste: dort bewegen sich die Wellen. */
float meerMaske(vec2 b) {
  float unten = smoothstep(0.398, 0.41, b.y) * smoothstep(0.97, 0.9, b.y);
  return unten * smoothstep(0.35, 0.33, b.x);
}
/* Gewitterwolke links oben (dunkel). */
float gewitterMaske(vec2 b, float lum) {
  return smoothstep(0.62, 0.38, lum) * smoothstep(0.58, 0.5, b.x) * smoothstep(0.42, 0.34, b.y);
}
/* Stadt am Hang (für nächtliche Lichter). */
float stadtMaske(vec2 b) {
  return smoothstep(0.36, 0.40, b.x) * smoothstep(0.66, 0.62, b.x) * smoothstep(0.44, 0.48, b.y) * smoothstep(0.82, 0.78, b.y);
}

void main() {
  /* Bildschirm → Foto (Foto deckt den Bildschirm ab, das Ausschnitt-Verhältnis ist fest). */
  vec2 bs = vec2(gl_FragCoord.x / uRes.x, 1.0 - gl_FragCoord.y / uRes.y);
  vec2 b = (bs - uAbb.xy) / uAbb.zw;
  b += uMaus * vec2(0.0035, 0.0025);

  float t = uZeit;
  float k = clamp(uTag, 0.0, 1.0);
  float nacht = smoothstep(0.66, 0.97, k);
  float tagAnteil = 1.0 - smoothstep(0.55, 0.82, k);

  /* Wellen: das Meer wird leicht verzerrt und bekommt wandernde Glanzpunkte. */
  float meer = meerMaske(b);
  vec2 wb = b;
  if (meer > 0.0) {
    wb += meer * vec2(sin(t * 0.9 + b.y * 90.0) * 0.0009 + sin(t * 0.37 + b.x * 40.0) * 0.0006,
                     cos(t * 0.7 + b.x * 60.0) * 0.0011);
  }
  vec3 col = texture(uFoto, wb).rgb;
  float lum = dot(col, vec3(0.3, 0.59, 0.11));

  /* Glanzpunkte auf den Wellen (wandern nach links, funkeln) */
  if (meer > 0.01) {
    vec2 g = vec2(b.x * IA * 110.0 + t * 1.6, b.y * 260.0);
    float punkt = step(0.985, hash(floor(g))) * (0.5 + 0.5 * sin(t * 4.0 + hash(floor(g)) * 30.0));
    col += vec3(1.0, 0.97, 0.9) * punkt * meer * 0.35 * (1.0 - nacht * 0.7);
  }

  /* Himmel: am Tag warme Abendtöne neutralisieren, damit der Sonnenlauf ruhig beginnt. */
  float himmel = himmelMaske(b);
  float warm = smoothstep(0.05, 0.22, col.r - col.b);
  // in Blau statt in Grün umfärben: die Helligkeit bleibt, nur der Farbton kippt
  vec3 tagesblau = vec3(lum * 0.62, lum * 0.82, lum * 1.18) + vec3(0.02, 0.03, 0.07);
  col = mix(col, tagesblau, warm * himmel * (1.0 - k) * 0.85);

  /* Sonne: im dritten Fenster von rechts (Mitte 58,5 % der Breite), sinkt beim Scrollen zum Horizont. */
  vec2 sonne = vec2(0.585, mix(0.14, 0.405, smoothstep(0.0, 0.72, k)));
  float sd = length((b - sonne) * vec2(IA, 1.0));
  vec3 sonnenFarbe = mix(vec3(1.0, 0.97, 0.9), vec3(1.0, 0.52, 0.22), smoothstep(0.3, 0.75, k));
  col += sonnenFarbe * (0.55 * exp(-sd * 6.5) + 1.2 * exp(-sd * 34.0)) * himmel * (1.0 - nacht);

  /* Nachthimmel: Verlauf, Sterne und Milchstraße über dem Himmel. */
  if (nacht > 0.001 && himmel > 0.001) {
    vec2 p = vec2(b.x * IA, b.y);
    float hz = horizont(b.x);
    float hoehe = clamp((hz - b.y) / (hz + 0.02), 0.0, 1.0);
    vec3 nachtHimmel = mix(vec3(0.02, 0.03, 0.08), vec3(0.002, 0.004, 0.015), pow(hoehe, 0.6));
    nachtHimmel += vec3(0.06, 0.05, 0.1) * exp(-(hz - b.y) * 14.0) * (0.5 + 0.5 * (1.0 - nacht));
    /* Milchstraße: schräges Band */
    float band = exp(-pow((b.y - (0.36 - 0.30 * b.x)) / 0.075, 2.0));
    float staub = fbm(p * vec2(3.0, 9.0) + 3.0);
    float dunkel = smoothstep(0.55, 0.75, fbm(p * vec2(6.0, 15.0) + 11.0));
    nachtHimmel += vec3(0.5, 0.52, 0.85) * band * (0.4 + 1.0 * staub) * (1.0 - 0.6 * dunkel) * 1.5;
    /* Sterne: zwei Größen, funkeln */
    float sterne = 0.0;
    for (int s = 0; s < 2; s++) {
      float skala = s == 0 ? 190.0 : 460.0;
      vec2 z = floor(p * skala);
      float h = hash(z + float(s) * 7.0);
      if (h > (s == 0 ? 0.986 : 0.972) - band * 0.03) {
        vec2 m = fract(p * skala) - 0.5 - (vec2(hash(z + 1.3), hash(z + 2.7)) - 0.5) * 0.6;
        float funkeln = 0.7 + 0.3 * sin(t * (1.5 + h * 4.0) + h * 40.0);
        sterne += smoothstep(0.24, 0.0, length(m)) * funkeln * (s == 0 ? 1.0 : 0.6);
      }
    }
    nachtHimmel += vec3(sterne) * 1.2;
    col = mix(col, nachtHimmel, himmel * nacht);
  }

  /* Gewitterwolke: Blitz beleuchtet sie von innen. */
  float gw = gewitterMaske(b, lum);
  col = mix(col, col * 1.7 + vec3(0.24, 0.28, 0.42), uBlitz * gw);

  /* Nacht am Land: Foto dunkler und kühler, Stadt bekommt warme Lichter. */
  vec3 nachtLand = col * vec3(0.22, 0.28, 0.46) + vec3(0.01, 0.012, 0.03);
  col = mix(col, nachtLand, nacht * (1.0 - himmel));
  float stadt = stadtMaske(b) * nacht;
  vec2 lg = vec2(b.x * IA * 230.0, b.y * 230.0);
  float licht = step(0.82, hash(floor(lg))) * smoothstep(0.42, 0.2, length(fract(lg) - 0.5));
  col += vec3(1.0, 0.72, 0.36) * licht * stadt * (0.7 + 0.3 * sin(t * 0.8 + hash(floor(lg)) * 40.0));

  /* Blitz-Pfad vom Wolkenrand ins Meer */
  if (uBlitz > 0.01) {
    vec2 q = vec2(b.x * IA, b.y);
    float db = 1.0;
    for (int i = 0; i < 7; i++) db = min(db, strecke(q, vec2(uBolt[i].x * IA, uBolt[i].y), vec2(uBolt[i + 1].x * IA, uBolt[i + 1].y)));
    col = mix(col, vec3(0.9, 0.94, 1.0), clamp(exp(-db * 900.0) * uBlitz * 1.6, 0.0, 1.0));
    col += vec3(0.45, 0.5, 0.75) * uBlitz * exp(-db * 45.0) * 0.25;
  }

  /* Sternschnuppe: heller Kopf mit kurzem Schweif */
  if (uSternT > 0.0 && uSternT < 1.0 && nacht > 0.2) {
    vec2 kopf = uStern.xy + uStern.zw * uSternT * 0.22;
    vec2 schwanz = kopf - uStern.zw * 0.07;
    vec2 q = vec2(b.x * IA, b.y);
    float ds = strecke(q, vec2(schwanz.x * IA, schwanz.y), vec2(kopf.x * IA, kopf.y));
    float entlang = clamp(dot(q - vec2(schwanz.x * IA, schwanz.y), normalize(vec2(uStern.z * IA, uStern.w))) / 0.07, 0.0, 1.0);
    col += vec3(0.9, 0.95, 1.0) * exp(-ds * 900.0) * entlang * sin(3.1416 * uSternT) * 1.6;
  }

  /* Leichte Vignette: das Auge bleibt in der Mitte */
  vec2 v = bs - 0.5;
  col *= 1.0 - dot(v, v) * 0.35;

  farbe = vec4(pow(max(col, 0.0), vec3(0.98)), 1.0);
}`,o=()=>{let e=new Date;return e.setHours(0,0,0,0),e};function s(e){let n=o();n.setDate(n.getDate()+t.vorlaufTage);let r=o();r.setMonth(r.getMonth()+t.monateVoraus);let i=e.getDay()===0?7:e.getDay();return e>=n&&e<=r&&t.wochentage.includes(i)}function c(e,t,i,a){e.replaceChildren();for(let t of[`Mo`,`Di`,`Mi`,`Do`,`Fr`,`Sa`,`So`]){let n=document.createElement(`span`);n.className=`ak-wt`,n.textContent=t,e.append(n)}let c=(t.getDay()+6)%7;for(let t=0;t<c;t++)e.append(document.createElement(`span`));let l=new Date(t.getFullYear(),t.getMonth()+1,0).getDate();for(let c=1;c<=l;c++){let l=new Date(t.getFullYear(),t.getMonth(),c),u=s(l),d=document.createElement(i?`button`:`span`);if(d.className=`ak-tag`,d.textContent=String(c),l.getTime()===o().getTime()&&d.classList.add(`ak-heute`),u||d.classList.add(`ak-belegt`),i){let e=d;e.type=`button`,e.disabled=!u,e.setAttribute(`aria-label`,`${r[l.getDay()]}, ${c}. ${n[l.getMonth()]}${u?``:`, nicht verfügbar`}`),e.addEventListener(`click`,()=>a?.(l))}e.append(d)}}function l(r){let i=new Date(o().getFullYear(),o().getMonth(),1),a=document.createElement(`button`);a.type=`button`,a.className=`ak-tisch`,a.setAttribute(`aria-label`,`Tischkalender: Termin auswählen`),a.innerHTML=`<span class="ak-ring" aria-hidden="true"></span><span class="ak-kopf" aria-hidden="true">${n[i.getMonth()]}</span><span class="ak-raster" aria-hidden="true"></span>`,c(a.querySelector(`.ak-raster`),i,!1),r.append(a);let s=document.createElement(`div`);s.className=`ak-gross`,s.setAttribute(`role`,`dialog`),s.setAttribute(`aria-modal`,`true`),s.setAttribute(`aria-labelledby`,`ak-titel`),s.hidden=!0,s.innerHTML=`
    <div class="ak-blatt">
      <div class="ak-ring" aria-hidden="true"></div>
      <div class="ak-monat">
        <button type="button" class="ak-pfeil" data-ak-zurueck aria-label="Vorheriger Monat">‹</button>
        <h2 id="ak-titel"></h2>
        <button type="button" class="ak-pfeil" data-ak-weiter aria-label="Nächster Monat">›</button>
      </div>
      <div class="ak-raster ak-raster-gross"></div>
      <p class="ak-hinweis">Tippe auf einen freien Tag. Dann geht es mit Uhrzeit und Kontakt weiter.</p>
    </div>
    <button type="button" class="ak-schliessen" data-ak-schliessen>← Zurück zum Schreibtisch</button>`,document.body.append(s);let l=document.createElement(`div`);l.className=`ak-hintergrund`,l.hidden=!0,document.body.append(l);let u=i,d=i,f=new Date(i.getFullYear(),i.getMonth()+t.monateVoraus,1),p=()=>{s.querySelector(`#ak-titel`).textContent=`${n[u.getMonth()]} ${u.getFullYear()}`,c(s.querySelector(`.ak-raster-gross`),u,!0,v),s.querySelector(`[data-ak-zurueck]`).disabled=u<=d,s.querySelector(`[data-ak-weiter]`).disabled=u>=f};s.querySelector(`[data-ak-zurueck]`).addEventListener(`click`,()=>{u=new Date(u.getFullYear(),u.getMonth()-1,1),p()}),s.querySelector(`[data-ak-weiter]`).addEventListener(`click`,()=>{u=new Date(u.getFullYear(),u.getMonth()+1,1),p()});function m(e){let t=a.getBoundingClientRect(),n=s.querySelector(`.ak-blatt`),r=n.getBoundingClientRect(),i=t.width/r.width,o=t.height/r.height,c=[{transform:`translate(${t.left+t.width/2-(r.left+r.width/2)}px, ${t.top+t.height/2-(r.top+r.height/2)}px) scale(${i}, ${o})`,opacity:.6},{transform:`none`,opacity:1}];return n.animate(e?c:c.reverse(),{duration:520,easing:`cubic-bezier(.2,.8,.2,1)`}).finished.catch(()=>{})}let h=()=>[...document.querySelectorAll(`.site-header, main, .site-footer`)];function g(){h().forEach(e=>e.inert=!0),u=i,p(),s.hidden=!1,l.hidden=!1,document.documentElement.classList.add(`ak-offen`),m(!0),l.animate([{opacity:0},{opacity:1}],{duration:400}),s.querySelector(`.ak-tag:not(:disabled)`)?.focus({preventScroll:!0})}async function _(e=!0){s.hidden||(l.animate([{opacity:1},{opacity:0}],{duration:350}),await m(!1),s.hidden=!0,l.hidden=!0,document.documentElement.classList.remove(`ak-offen`),h().forEach(e=>e.inert=!1),e&&a.focus({preventScroll:!0}))}async function v(t){await _(!1);let{oeffneTerminbuch:n}=await e(async()=>{let{oeffneTerminbuch:e}=await import(`./terminbuch.D7DG0jp5.js`);return{oeffneTerminbuch:e}},__vite__mapDeps([0,1]));n(t)}return a.addEventListener(`click`,g),s.querySelector(`[data-ak-schliessen]`).addEventListener(`click`,()=>_()),l.addEventListener(`click`,()=>_()),addEventListener(`keydown`,e=>{e.key===`Escape`&&!s.hidden&&_()}),a}var u=`(min-width: 1280px) and (pointer: fine) and (prefers-reduced-motion: no-preference)`,d={b:2e3,h:1068,kal:{x:.098,y:.691,w:.078}};function f(e){let t=(t,n)=>{let r=e.createShader(t);if(e.shaderSource(r,n),e.compileShader(r),!e.getShaderParameter(r,e.COMPILE_STATUS))throw Error(e.getShaderInfoLog(r)??`Shader`);return r};try{let n=e.createProgram();if(e.attachShader(n,t(e.VERTEX_SHADER,i)),e.attachShader(n,t(e.FRAGMENT_SHADER,a)),e.linkProgram(n),!e.getProgramParameter(n,e.LINK_STATUS))throw Error(e.getProgramInfoLog(n)??`Programm`);e.useProgram(n);let r=e.createBuffer();e.bindBuffer(e.ARRAY_BUFFER,r),e.bufferData(e.ARRAY_BUFFER,new Float32Array([-1,-1,3,-1,-1,3]),e.STATIC_DRAW);let o=e.getAttribLocation(n,`a`);e.enableVertexAttribArray(o),e.vertexAttribPointer(o,2,e.FLOAT,!1,0,0);let s={};for(let t of[`uFoto`,`uRes`,`uAbb`,`uZeit`,`uTag`,`uMaus`,`uBlitz`,`uBolt`,`uStern`,`uSternT`])s[t]=e.getUniformLocation(n,t);return s}catch(e){return console.warn(`Aussicht: Grafik nicht verfügbar`,e),null}}function p(e){if(!document.querySelector(`.monitor-geraet`))return!1;let t=document.createElement(`div`);t.className=`aussicht`,t.innerHTML=`<canvas class="aussicht-szene" aria-hidden="true"></canvas>`;let n=t.querySelector(`canvas`),r=n.getContext(`webgl2`,{antialias:!1,alpha:!1,powerPreference:`low-power`}),i=r?f(r):null;if(!r||!i)return!1;let a=new Image;a.decoding=`async`,a.src=`/aussicht/fenster.webp`,a.onerror=()=>{t.remove(),o.remove(),e()},a.onload=()=>{let e=r.createTexture();r.bindTexture(r.TEXTURE_2D,e),r.texParameteri(r.TEXTURE_2D,r.TEXTURE_MIN_FILTER,r.LINEAR),r.texParameteri(r.TEXTURE_2D,r.TEXTURE_MAG_FILTER,r.LINEAR),r.texParameteri(r.TEXTURE_2D,r.TEXTURE_WRAP_S,r.CLAMP_TO_EDGE),r.texParameteri(r.TEXTURE_2D,r.TEXTURE_WRAP_T,r.CLAMP_TO_EDGE),r.texImage2D(r.TEXTURE_2D,0,r.RGB,r.RGB,r.UNSIGNED_BYTE,a),r.uniform1i(i.uFoto,0),document.body.prepend(t),M()};let o=document.createElement(`div`);o.className=`aussicht-kalender`,document.body.append(o),l(o);let s=document.documentElement,c=matchMedia(u),p={x:0,y:0,zx:0,zy:0},m=0,h=new Float32Array(16),g=-1,_=new Float32Array(4),v=0,y=0,b=0,x=0,S=0,C=new Float32Array(4);function w(){let e=Math.min(devicePixelRatio||1,1.5);n.width=Math.round(innerWidth*e),n.height=Math.round(innerHeight*e),r.viewport(0,0,n.width,n.height);let t=Math.max(innerWidth/d.b,innerHeight/d.h),i=d.b*t,a=d.h*t,s=(innerWidth-i)/2,c=(innerHeight-a)/2;C.set([s/innerWidth,c/innerHeight,i/innerWidth,a/innerHeight]),o.style.setProperty(`--ak-x`,`${Math.round(s+d.kal.x*i)}px`),o.style.setProperty(`--ak-y`,`${Math.round(c+d.kal.y*a)}px`),o.style.setProperty(`--ak-w`,`${Math.round(d.kal.w*i)}px`)}w(),addEventListener(`resize`,w),addEventListener(`pointermove`,e=>{p.zx=e.clientX/innerWidth*2-1,p.zy=e.clientY/innerHeight*2-1},{passive:!0});function T(){let e=.3+(Math.random()-.5)*.06,t=.36;for(let n=0;n<8;n++)h[n*2]=e,h[n*2+1]=t,e+=(Math.random()-.5)*.012,t+=.02+Math.random()*.012;let n=performance.now(),r=e=>{let t=(e-n)/1e3;m=t<.08?1:t<.16?.25:t<.24?.85:Math.max(0,.85-(t-.24)*2.5),m>0&&requestAnimationFrame(r)};requestAnimationFrame(r)}function E(){setTimeout(()=>{T(),E()},3e4+Math.random()*35e3)}E();function D(){_[0]=.15+Math.random()*.6,_[1]=.06+Math.random()*.12;let e=-.55-Math.random()*.5;_[2]=Math.cos(e)*.8,_[3]=Math.sin(e)*.8,g=performance.now()}function O(){setTimeout(()=>{v>.8&&D(),O()},1e4+Math.random()*15e3)}O();let k=()=>{let e=document.documentElement.scrollHeight-innerHeight;return e>0?Math.min(1,Math.max(0,scrollY/e)):0};v=y=k(),addEventListener(`scroll`,()=>y=k(),{passive:!0});let A=()=>{cancelAnimationFrame(x),x=requestAnimationFrame(j)};document.addEventListener(`visibilitychange`,()=>{document.hidden?cancelAnimationFrame(x):A()});function j(e){if(x=requestAnimationFrame(j),e-b<32||!c.matches||s.classList.contains(`ak-offen`)||document.querySelector(`dialog[open]`))return;let t=Math.min(.5,(e-(b||e))/1e3);b=e,v+=(y-v)*(1-Math.exp(-t/.25)),Math.abs(y-v)<.001&&(v=y),p.x+=(p.zx-p.x)*(1-Math.exp(-t/.6)),p.y+=(p.zy-p.y)*(1-Math.exp(-t/.6));let a=g<0?-1:(e-g)/900;a>1&&(g=-1);let o=r;o.uniform2f(i.uRes,n.width,n.height),o.uniform4fv(i.uAbb,C),o.uniform1f(i.uZeit,(e-S)/1e3),o.uniform1f(i.uTag,v),o.uniform2f(i.uMaus,p.x,p.y),o.uniform1f(i.uBlitz,m),o.uniform2fv(i.uBolt,h),o.uniform4fv(i.uStern,_),o.uniform1f(i.uSternT,a),o.drawArrays(o.TRIANGLES,0,3)}function M(){S=performance.now(),b=0,A()}return window.aussicht={get tag(){return v},get blitz(){return m},get sternschnuppe(){return g>=0},testBlitz:T,testSternschnuppe:D},!0}export{p as starteAussicht};