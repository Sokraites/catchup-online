const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["_astro/terminbuch.Dw5lXww5.js","_astro/stufe.DiRvSDRL.js"])))=>i.map(i=>d[i]);
import{t as e}from"./preload-helper.DHhhL8Zf.js";import{t}from"./index.astro_astro_type_script_index_0_lang.-uBPORDH.js";var n={wochentage:[1,2,3,4,5],zeiten:[`09:00`,`10:30`,`13:00`,`14:30`,`16:00`],vorlaufTage:1,monateVoraus:3,gespraechsarten:[`Telefon`,`Video`,`Vor Ort im ${t.region.schwerpunkt}`]},r=[`Januar`,`Februar`,`März`,`April`,`Mai`,`Juni`,`Juli`,`August`,`September`,`Oktober`,`November`,`Dezember`],i=[`Sonntag`,`Montag`,`Dienstag`,`Mittwoch`,`Donnerstag`,`Freitag`,`Samstag`],a=`#version 300 es
in vec2 a;
void main() { gl_Position = vec4(a, 0.0, 1.0); }`,o=`#version 300 es
precision highp float;
out vec4 farbe;
uniform vec2 uRes;
uniform float uZeit;     // Sekunden
uniform float uTag;      // 0 = Mittag … 1 = Nacht (Scrollfortschritt)
uniform vec2 uMaus;      // -1 … 1, für Tiefe (Ebenen verschieben sich verschieden stark)
uniform float uLinks;    // rechter Rand des linken Fensterflügels (0 … 1)
uniform float uRechts;   // linker Rand des rechten Fensterflügels (0 … 1)
uniform float uRahmenL;  // Innenkante des Fensterrahmens links (0 … 1)
uniform float uRahmenR;  // Innenkante des Fensterrahmens rechts (0 … 1)
uniform float uBlitz;    // Helligkeit des Blitzes 0 … 1
uniform vec2 uBolt[8];   // Blitz-Verlauf (Bildschirm-Koordinaten 0 … 1)
uniform vec4 uStern;     // Sternschnuppe: Start xy, Richtung xy
uniform float uSternT;   // Fortschritt 0 … 1 (außerhalb: aus)

const float H = 0.5;     // Horizont (hoch: Blick vom erhöhten Haus hinunter aufs Meer)

float hash(vec2 p) { p = fract(p * vec2(123.34, 456.21)); p += dot(p, p + 45.32); return fract(p.x * p.y); }
float rausch(vec2 p) {
  vec2 i = floor(p), f = fract(p);
  vec2 u = f * f * (3.0 - 2.0 * f);
  return mix(mix(hash(i), hash(i + vec2(1, 0)), u.x), mix(hash(i + vec2(0, 1)), hash(i + vec2(1, 1)), u.x), u.y);
}
float fbm(vec2 p) {
  float s = 0.0, a = 0.5;
  for (int i = 0; i < 5; i++) { s += a * rausch(p); p = p * 2.03 + 17.1; a *= 0.5; }
  return s;
}
float fbm3(vec2 p) {
  float s = 0.0, a = 0.5;
  for (int i = 0; i < 3; i++) { s += a * rausch(p); p = p * 2.07 + 31.7; a *= 0.5; }
  return s / 0.875;
}
float grat(float x) { return 1.0 - abs(rausch(vec2(x, 0.5)) * 2.0 - 1.0); }
float gebirge(float x) { return 0.55 * grat(x) + 0.3 * grat(x * 2.1 + 3.0) + 0.15 * grat(x * 4.7 + 7.0); }
float strecke(vec2 p, vec2 a, vec2 b) {
  vec2 pa = p - a, ba = b - a;
  float h = clamp(dot(pa, ba) / dot(ba, ba), 0.0, 1.0);
  return length(pa - ba * h);
}
// weiche Kante (gegen Treppen): 1 unterhalb der Linie, 0 darüber
float unter(float y, float linie, float px) { return smoothstep(linie + px, linie - px, y); }

// Himmelsfarbe ohne Sonne und Sterne (auch für Spiegelungen im Wasser)
vec3 himmel(float hoehe, float e) {
  vec3 zenTag = vec3(0.14, 0.36, 0.78), horTag = vec3(0.60, 0.79, 0.95);
  vec3 zenAbend = vec3(0.16, 0.18, 0.40), horAbend = vec3(1.0, 0.48, 0.22);
  vec3 zenNacht = vec3(0.004, 0.006, 0.02), horNacht = vec3(0.045, 0.055, 0.13);
  vec3 zen = mix(mix(zenNacht, zenAbend, smoothstep(-0.38, 0.0, e)), zenTag, smoothstep(0.08, 0.5, e));
  vec3 hor = mix(mix(horNacht, horAbend, smoothstep(-0.30, 0.0, e)), horTag, smoothstep(0.12, 0.55, e));
  return mix(hor, zen, pow(clamp(hoehe, 0.0, 1.0), 0.55));
}

void main() {
  vec2 uv = gl_FragCoord.xy / uRes;
  float A = uRes.x / uRes.y;
  float t = uZeit;
  float px = 1.5 / uRes.y;
  float mx = uMaus.x;

  // Sonnenstand: hoch am Anfang, unter dem Horizont am Ende
  float k = clamp(uTag, 0.0, 1.0);
  float e = clamp(1.0 - 1.39 * k, -0.5, 1.0);
  float nacht = smoothstep(0.0, -0.36, e);
  float abend = smoothstep(0.08, -0.12, e);
  float sichtbar = smoothstep(-0.07, 0.02, e);
  float rot = exp(-pow((e - 0.02) / 0.18, 2.0));
  float flL = uLinks - uRahmenL;  // Breite des linken Flügels
  vec2 sonne = vec2(uRahmenL + flL * mix(0.80, 0.62, k), H + e * 0.33);
  vec3 sonnenFarbe = mix(vec3(1.0, 0.42, 0.18), vec3(1.0, 0.97, 0.88), smoothstep(0.0, 0.45, e));
  float wolkeX = uRahmenL + flL * 0.32 + mx * 0.004;
  vec3 dunstFarbe = himmel(0.05, e);

  vec3 col;
  float hoehe = (uv.y - H) / (1.0 - H);

  if (uv.y >= H) {
    // ---------- Himmel ----------
    col = himmel(hoehe, e);
    float d = length((uv - sonne) * vec2(A, 1.0));
    col += sonnenFarbe * (0.30 * exp(-d * 5.0) + 0.55 * exp(-d * 22.0)) * sichtbar;
    col += vec3(1.0, 0.36, 0.16) * rot * 0.55 * exp(-(uv.y - H) * 9.0) * exp(-abs(uv.x - sonne.x) * 1.6);
    col = mix(col, sonnenFarbe * 1.2, smoothstep(0.032, 0.026, d) * sichtbar);

    // Sterne und Milchstraße (flaches Band über beide Fensterflügel)
    if (nacht > 0.001) {
      vec2 p = vec2(uv.x * A, uv.y);
      vec2 r = vec2(p.x * 0.98 + p.y * 0.2, -p.x * 0.2 + p.y * 0.98);
      float band = exp(-pow((r.y - 0.66) / 0.11, 2.0));
      float staub = fbm(r * vec2(3.5, 11.0) + 3.0);
      float dunkel = smoothstep(0.5, 0.7, fbm(r * vec2(6.0, 18.0) + 11.0)) * smoothstep(0.3, 0.9, band);
      float kern = exp(-pow((r.x - 0.35) / 0.45, 2.0));
      vec3 milch = mix(vec3(0.55, 0.62, 0.98), vec3(1.0, 0.85, 0.66), kern) * band * (0.3 + 0.9 * staub) * (1.0 - 0.8 * dunkel);
      float sterne = 0.0;
      for (int s = 0; s < 2; s++) {
        float skala = s == 0 ? 180.0 : 420.0;
        vec2 z = floor(p * skala);
        float h = hash(z + float(s) * 7.0);
        float schwelle = (s == 0 ? 0.988 : 0.975) - band * 0.04;
        if (h > schwelle) {
          vec2 m = fract(p * skala) - 0.5 - (vec2(hash(z + 1.3), hash(z + 2.7)) - 0.5) * 0.6;
          float funkeln = 0.65 + 0.35 * sin(t * (1.5 + h * 4.0) + h * 40.0);
          sterne += smoothstep(0.24, 0.0, length(m)) * funkeln * (s == 0 ? 1.0 : 0.55);
        }
      }
      col += (milch * 1.1 + vec3(sterne)) * nacht * smoothstep(0.0, 0.2, hoehe);
    }

    // Sternschnuppe
    if (uSternT > 0.0 && uSternT < 1.0) {
      vec2 kopf = uStern.xy + uStern.zw * uSternT * 0.22;
      vec2 schwanz = kopf - uStern.zw * 0.07;
      vec2 q = vec2(uv.x * A, uv.y);
      float ds = strecke(q, vec2(schwanz.x * A, schwanz.y), vec2(kopf.x * A, kopf.y));
      float entlang = clamp(dot(q - vec2(schwanz.x * A, schwanz.y), normalize(vec2(uStern.z * A, uStern.w))) / 0.07, 0.0, 1.0);
      col += vec3(0.9, 0.95, 1.0) * exp(-ds * 900.0) * entlang * sin(3.1416 * uSternT) * 1.6 * nacht;
    }

    // Ferne Küste über die ganze Breite (sehr flach, im Dunst)
    float kueste = H + 0.006 + 0.012 * gebirge(uv.x * 9.0 + mx * 0.01);
    col = mix(col, mix(dunstFarbe, vec3(0.02, 0.025, 0.05), 0.35 + 0.5 * nacht), unter(uv.y, kueste, px) * 0.7);

    // Gewitterwolke: Amboss über breiter Basis, mit Nebenzellen und Regenschleier; nachts flache Wolkenbank am Horizont
    float flach = mix(1.0, 0.32, nacht);
    float basis = H + mix(0.035, 0.012, nacht);
    vec2 q = vec2((uv.x - wolkeX) * A, (uv.y - basis) / flach);
    float y = q.y;
    float halb = mix(0.085, 0.055, smoothstep(0.0, 0.11, y)) + smoothstep(0.1, 0.18, y) * 0.075;
    float form = (halb - abs(q.x - 0.03 * y)) / halb;
    float hauptzelle = form * smoothstep(-0.005, 0.012, y) * smoothstep(0.205, 0.17, y + (rausch(vec2(q.x * 30.0, 2.0)) - 0.5) * 0.02);
    // flache Wolkenschicht an der Basis, die in die Hauptzelle übergeht
    float schicht = (1.0 - abs(q.y - 0.012) / 0.014) * smoothstep(0.17, 0.08, abs(q.x));
    float dichte = max(hauptzelle, schicht) + (fbm(q * 22.0 + vec2(t * 0.012, 0.0)) - 0.5) * 0.6;
    float deck = smoothstep(0.0, 0.3, dichte);
    // Regenschleier unter der Wolke
    float regen = smoothstep(0.06, 0.0, abs(q.x + 0.01)) * step(uv.y, basis) * smoothstep(H, H + 0.006, uv.y) * 0.35;
    if (deck > 0.0 || regen > 0.0) {
      float innen = fbm(q * 18.0 + 4.0);
      float oben = smoothstep(-0.01, 0.16, y) * 0.8 + 0.2;
      vec3 hell = mix(vec3(0.95, 0.96, 0.99), vec3(1.0, 0.62, 0.42), smoothstep(0.45, 0.05, e));
      vec3 schatten = mix(vec3(0.36, 0.38, 0.45), vec3(0.22, 0.14, 0.22), smoothstep(0.45, 0.05, e));
      vec3 wolke = mix(schatten, hell, clamp(oben * 0.9 + innen * 0.45 - 0.15, 0.0, 1.0));
      wolke = mix(vec3(0.02, 0.025, 0.045) + vec3(0.03) * innen, wolke, smoothstep(-0.3, 0.05, e));
      wolke += vec3(0.75, 0.80, 1.0) * uBlitz * (0.35 + 0.9 * innen) * (1.0 - oben * 0.4);
      col = mix(col, schatten * 0.9 + vec3(0.6, 0.65, 0.9) * uBlitz * 0.3, regen * (1.0 - deck));
      col = mix(col, wolke, deck * 0.97);
    }

    // Gebirge (rechter Flügel): ferne Kette mit Schnee, nahe Kette; Tiefe durch unterschiedliche Verschiebung
    float rampe = smoothstep(uRechts - 0.02, uRechts + 0.06, uv.x);
    float fern = H + rampe * (0.09 + 0.18 * gebirge(uv.x * 3.2 + mx * 0.012));
    float nah = H + rampe * (0.035 + 0.08 * gebirge(uv.x * 6.0 + 5.0 + mx * 0.03));
    vec3 fernFarbe = mix(dunstFarbe, mix(vec3(0.008, 0.01, 0.022), vec3(0.32, 0.38, 0.52), smoothstep(-0.2, 0.4, e)), 0.55 + 0.4 * nacht);
    float schnee = smoothstep(fern - 0.03, fern - 0.008, uv.y) * smoothstep(H + 0.14, H + 0.2, fern) * (0.6 + 0.4 * rausch(vec2(uv.x * 80.0, uv.y * 40.0)));
    vec3 berg = mix(fernFarbe, mix(vec3(0.1, 0.1, 0.14), vec3(0.95, 0.96, 1.0), smoothstep(-0.1, 0.3, e)), schnee * 0.8) + sonnenFarbe * 0.12 * rot;
    col = mix(col, berg, unter(uv.y, fern, px));
    vec3 hang = mix(vec3(0.01, 0.012, 0.02), vec3(0.16, 0.23, 0.19), smoothstep(-0.25, 0.45, e));
    hang *= 0.8 + 0.35 * fbm(vec2(uv.x * 50.0, uv.y * 70.0));
    col = mix(col, hang, unter(uv.y, nah, px));

    // Stadt am Hang: gestaffelte Häuserreihen von der Küste aufwärts (hintere Reihen zuerst)
    float stadtX = smoothstep(uRechts + 0.01, uRechts + 0.04, uv.x) * smoothstep(uRahmenR, uRahmenR - 0.03, uv.x);
    if (stadtX > 0.0 && uv.y < nah + 0.02) {
      float sx = (uv.x + mx * 0.02) * A / 0.0062;
      float spalte = floor(sx);
      float inSpalte = fract(sx);
      for (int r = 5; r >= 0; r--) {
        float fr = float(r);
        float reihe = H + 0.002 + (nah - H) * (0.04 + fr * 0.15) * stadtX;
        float hh = (0.005 + 0.011 * hash(vec2(spalte, fr * 3.1))) * (1.0 - fr * 0.1);
        float lueckeX = step(0.1, inSpalte) * step(hash(vec2(spalte, fr + 9.0)), 0.88);
        if (uv.y > reihe && uv.y < reihe + hh && lueckeX > 0.0 && reihe < nah) {
          float art = hash(vec2(spalte, fr + 11.0));
          vec3 fassade = mix(vec3(0.93, 0.90, 0.84), vec3(0.88, 0.70, 0.55), step(0.65, art));
          fassade *= inSpalte < 0.38 ? 0.74 : 1.0;
          if (uv.y > reihe + hh * 0.78) fassade = mix(vec3(0.66, 0.32, 0.22), vec3(0.42, 0.44, 0.48), step(0.55, art));
          vec3 haus = mix(vec3(0.015, 0.015, 0.03), fassade, smoothstep(-0.2, 0.35, e));
          haus = mix(haus, haus * sonnenFarbe * 1.25, rot * 0.5);
          vec2 fz = vec2(sx * 3.0, (uv.y - reihe) / 0.0024);
          float an = step(0.55, hash(floor(fz) + spalte)) * step(fract(fz.y), 0.55) * step(fract(fz.x), 0.5) * step(uv.y, reihe + hh * 0.75);
          haus += vec3(1.0, 0.78, 0.45) * an * abend * (0.8 + 0.2 * sin(t * 0.7 + hash(floor(fz)) * 30.0));
          col = haus;
        }
      }
    }
    // Dunst über dem Horizont
    col = mix(col, dunstFarbe, exp(-(uv.y - H) * 60.0) * 0.3 * (1.0 - nacht * 0.7));
  } else {
    // ---------- Meer (von oben gesehen) ----------
    float tiefe = H - uv.y;
    float z = 0.08 / max(tiefe, 0.002);
    vec2 w = vec2((uv.x - 0.5 + mx * 0.01) * A * z, z);
    vec2 strom = vec2(t * 0.05, t * 0.11);
    float wl = fbm3(w * vec2(1.6, 3.0) + strom) * 0.6 + fbm3(w * vec2(4.0, 7.0) - strom * 1.7) * 0.4;
    float wr = fbm3((w + vec2(0.02, 0.0)) * vec2(1.6, 3.0) + strom) * 0.6 + fbm3((w + vec2(0.02, 0.0)) * vec2(4.0, 7.0) - strom * 1.7) * 0.4;
    float wo = fbm3((w + vec2(0.0, 0.02)) * vec2(1.6, 3.0) + strom) * 0.6 + fbm3((w + vec2(0.0, 0.02)) * vec2(4.0, 7.0) - strom * 1.7) * 0.4;
    vec2 n = vec2(wr - wl, wo - wl) * 12.0;
    float fresnel = pow(1.0 - clamp(tiefe * 2.2, 0.0, 1.0), 4.0);
    vec3 tief = mix(mix(vec3(0.004, 0.008, 0.02), vec3(0.10, 0.06, 0.10), smoothstep(-0.3, 0.0, e)), vec3(0.03, 0.17, 0.28), smoothstep(0.1, 0.5, e));
    vec3 spiegel = himmel(0.15 + n.y * 0.4, e);
    col = mix(tief, spiegel, 0.25 + 0.6 * fresnel);
    col *= 0.85 + 0.3 * wl;
    float spur = exp(-pow((uv.x - sonne.x + n.x * 0.03) * A / (0.012 + tiefe * 0.35), 2.0));
    float glanz = pow(clamp(wl * 1.25, 0.0, 1.0), 6.0);
    col += sonnenFarbe * spur * glanz * 2.2 * sichtbar;
    float stadtSpur = smoothstep(uRechts + 0.01, uRechts + 0.04, uv.x) * smoothstep(uRahmenR, uRahmenR - 0.03, uv.x);
    float lichtSaeule = step(0.7, hash(vec2(floor((uv.x + mx * 0.02) * A / 0.0062), 5.0)));
    col += vec3(1.0, 0.75, 0.4) * stadtSpur * lichtSaeule * abend * exp(-tiefe * 16.0) * (0.25 + 0.5 * glanz);
    col += vec3(0.6, 0.65, 0.9) * uBlitz * 0.3 * exp(-abs(uv.x - wolkeX) * A * 6.0) * exp(-tiefe * 6.0);
    col += vec3(0.8) * smoothstep(0.82, 0.92, wl) * (1.0 - fresnel) * smoothstep(-0.2, 0.3, e) * 0.35;

    // Bewaldeter Hang im Vordergrund: Das Haus steht erhöht, man schaut hinunter
    float vorn = 0.17 + 0.07 * smoothstep(0.35, 1.0, uv.x) + 0.03 * fbm((uv.x + mx * 0.05) * vec2(7.0, 1.0)) + 0.012 * (rausch(vec2((uv.x + mx * 0.05) * 160.0, 1.0)) - 0.5);
    vec3 wald = mix(vec3(0.008, 0.012, 0.012), vec3(0.12, 0.2, 0.12), smoothstep(-0.2, 0.4, e));
    wald *= 0.75 + 0.5 * fbm(vec2(uv.x * 90.0, uv.y * 90.0));
    wald = mix(wald, wald * sonnenFarbe * 1.4, rot * 0.4);
    // ein paar Häuser im Wald, abends erleuchtet
    vec2 hzf = vec2((uv.x + mx * 0.05) * A / 0.01, uv.y / 0.012);
    vec2 hz = floor(hzf);
    float punkt = smoothstep(0.22, 0.05, length(fract(hzf) - 0.5));
    float licht = step(0.9, hash(hz)) * punkt * step(uv.y, vorn - 0.02);
    wald += vec3(1.0, 0.75, 0.42) * licht * abend * 0.9;
    col = mix(col, wald, unter(uv.y, vorn, px));
  }

  // Blitz: leuchtender Pfad, am Tag als helle Linie (nicht nur aufaddiert)
  if (uBlitz > 0.01) {
    vec2 qq = vec2(uv.x * A, uv.y);
    float db = 1.0;
    for (int i = 0; i < 7; i++) db = min(db, strecke(qq, vec2(uBolt[i].x * A, uBolt[i].y), vec2(uBolt[i + 1].x * A, uBolt[i + 1].y)));
    col = mix(col, vec3(0.92, 0.95, 1.0), clamp(exp(-db * 900.0) * uBlitz * 1.6, 0.0, 1.0));
    col += vec3(0.5, 0.55, 0.8) * uBlitz * exp(-db * 50.0) * 0.25;
  }

  farbe = vec4(pow(col, vec3(0.95)), 1.0);
}`;function s(e){let t=(t,n)=>{let r=e.createShader(t);if(e.shaderSource(r,n),e.compileShader(r),!e.getShaderParameter(r,e.COMPILE_STATUS))throw Error(e.getShaderInfoLog(r)??`Shader`);return r},n=e.createProgram();if(e.attachShader(n,t(e.VERTEX_SHADER,a)),e.attachShader(n,t(e.FRAGMENT_SHADER,o)),e.linkProgram(n),!e.getProgramParameter(n,e.LINK_STATUS))throw Error(e.getProgramInfoLog(n)??`Programm`);e.useProgram(n);let r=e.createBuffer();e.bindBuffer(e.ARRAY_BUFFER,r),e.bufferData(e.ARRAY_BUFFER,new Float32Array([-1,-1,3,-1,-1,3]),e.STATIC_DRAW);let i=e.getAttribLocation(n,`a`);e.enableVertexAttribArray(i),e.vertexAttribPointer(i,2,e.FLOAT,!1,0,0);let s={};for(let t of[`uRes`,`uZeit`,`uTag`,`uMaus`,`uLinks`,`uRechts`,`uRahmenL`,`uRahmenR`,`uBlitz`,`uBolt`,`uStern`,`uSternT`])s[t]=e.getUniformLocation(n,t);return s}var c=()=>{let e=new Date;return e.setHours(0,0,0,0),e};function l(e){let t=c();t.setDate(t.getDate()+n.vorlaufTage);let r=c();r.setMonth(r.getMonth()+n.monateVoraus);let i=e.getDay()===0?7:e.getDay();return e>=t&&e<=r&&n.wochentage.includes(i)}function u(e,t,n,a){e.replaceChildren();for(let t of[`Mo`,`Di`,`Mi`,`Do`,`Fr`,`Sa`,`So`]){let n=document.createElement(`span`);n.className=`ak-wt`,n.textContent=t,e.append(n)}let o=(t.getDay()+6)%7;for(let t=0;t<o;t++)e.append(document.createElement(`span`));let s=new Date(t.getFullYear(),t.getMonth()+1,0).getDate();for(let o=1;o<=s;o++){let s=new Date(t.getFullYear(),t.getMonth(),o),u=l(s),d=document.createElement(n?`button`:`span`);if(d.className=`ak-tag`,d.textContent=String(o),s.getTime()===c().getTime()&&d.classList.add(`ak-heute`),u||d.classList.add(`ak-belegt`),n){let e=d;e.type=`button`,e.disabled=!u,e.setAttribute(`aria-label`,`${i[s.getDay()]}, ${o}. ${r[s.getMonth()]}${u?``:`, nicht verfügbar`}`),e.addEventListener(`click`,()=>a?.(s))}e.append(d)}}function d(t){let i=new Date(c().getFullYear(),c().getMonth(),1),a=document.createElement(`button`);a.type=`button`,a.className=`ak-tisch`,a.setAttribute(`aria-label`,`Tischkalender: Termin auswählen`),a.innerHTML=`<span class="ak-ring" aria-hidden="true"></span><span class="ak-kopf" aria-hidden="true">${r[i.getMonth()]}</span><span class="ak-raster" aria-hidden="true"></span>`,u(a.querySelector(`.ak-raster`),i,!1),t.append(a);let o=document.createElement(`div`);o.className=`ak-gross`,o.setAttribute(`role`,`dialog`),o.setAttribute(`aria-modal`,`true`),o.setAttribute(`aria-labelledby`,`ak-titel`),o.hidden=!0,o.innerHTML=`
    <div class="ak-blatt">
      <div class="ak-ring" aria-hidden="true"></div>
      <div class="ak-monat">
        <button type="button" class="ak-pfeil" data-ak-zurueck aria-label="Vorheriger Monat">‹</button>
        <h2 id="ak-titel"></h2>
        <button type="button" class="ak-pfeil" data-ak-weiter aria-label="Nächster Monat">›</button>
      </div>
      <div class="ak-raster ak-raster-gross"></div>
      <p class="ak-hinweis">Tippe auf einen freien Tag. Dann geht es mit Uhrzeit und Kontakt weiter.</p>
    </div>
    <button type="button" class="ak-schliessen" data-ak-schliessen>← Zurück zum Schreibtisch</button>`,document.body.append(o);let s=document.createElement(`div`);s.className=`ak-hintergrund`,s.hidden=!0,document.body.append(s);let l=i,d=i,f=new Date(i.getFullYear(),i.getMonth()+n.monateVoraus,1),p=()=>{o.querySelector(`#ak-titel`).textContent=`${r[l.getMonth()]} ${l.getFullYear()}`,u(o.querySelector(`.ak-raster-gross`),l,!0,v),o.querySelector(`[data-ak-zurueck]`).disabled=l<=d,o.querySelector(`[data-ak-weiter]`).disabled=l>=f};o.querySelector(`[data-ak-zurueck]`).addEventListener(`click`,()=>{l=new Date(l.getFullYear(),l.getMonth()-1,1),p()}),o.querySelector(`[data-ak-weiter]`).addEventListener(`click`,()=>{l=new Date(l.getFullYear(),l.getMonth()+1,1),p()});function m(e){let t=a.getBoundingClientRect(),n=o.querySelector(`.ak-blatt`),r=n.getBoundingClientRect(),i=t.width/r.width,s=t.height/r.height,c=[{transform:`translate(${t.left+t.width/2-(r.left+r.width/2)}px, ${t.top+t.height/2-(r.top+r.height/2)}px) scale(${i}, ${s})`,opacity:.6},{transform:`none`,opacity:1}];return n.animate(e?c:c.reverse(),{duration:520,easing:`cubic-bezier(.2,.8,.2,1)`}).finished.catch(()=>{})}let h=()=>[...document.querySelectorAll(`.site-header, main, .site-footer`)];function g(){h().forEach(e=>e.inert=!0),l=i,p(),o.hidden=!1,s.hidden=!1,document.documentElement.classList.add(`ak-offen`),m(!0),s.animate([{opacity:0},{opacity:1}],{duration:400}),o.querySelector(`.ak-tag:not(:disabled)`)?.focus({preventScroll:!0})}async function _(e=!0){o.hidden||(s.animate([{opacity:1},{opacity:0}],{duration:350}),await m(!1),o.hidden=!0,s.hidden=!0,document.documentElement.classList.remove(`ak-offen`),h().forEach(e=>e.inert=!1),e&&a.focus({preventScroll:!0}))}async function v(t){await _(!1);let{oeffneTerminbuch:n}=await e(async()=>{let{oeffneTerminbuch:e}=await import(`./terminbuch.Dw5lXww5.js`);return{oeffneTerminbuch:e}},__vite__mapDeps([0,1]));n(t)}return a.addEventListener(`click`,g),o.querySelector(`[data-ak-schliessen]`).addEventListener(`click`,()=>_()),s.addEventListener(`click`,()=>_()),addEventListener(`keydown`,e=>{e.key===`Escape`&&!o.hidden&&_()}),a}var f=.5,p=`(min-width: 1280px) and (pointer: fine) and (prefers-reduced-motion: no-preference)`;function m(){let e=document.querySelector(`.monitor-geraet`);if(!e)return!1;let t=document.createElement(`div`);t.className=`aussicht`,t.innerHTML=`
    <canvas class="aussicht-szene" aria-hidden="true"></canvas>
    <div class="aussicht-raum" aria-hidden="true">
      <div class="aussicht-wand"></div>
      <div class="aussicht-rahmen"><span class="aussicht-sprosse aussicht-sprosse-l"></span><span class="aussicht-sprosse aussicht-sprosse-r"></span><span class="aussicht-kaempfer"></span></div>
      <div class="aussicht-glas"></div>
      <div class="aussicht-tisch"></div>
    </div>`;let n=t.querySelector(`canvas`),r=n.getContext(`webgl2`,{antialias:!1,alpha:!1,powerPreference:`low-power`});if(!r)return!1;let i;try{i=s(r)}catch(e){return console.warn(`Aussicht: Grafik nicht verfügbar`,e),!1}document.body.prepend(t);let a=document.createElement(`div`);a.className=`aussicht-kalender`;let o=document.querySelector(`main`);o?o.prepend(a):document.body.append(a),d(a);let c=document.documentElement,l=matchMedia(p),u=.6,m=.2,h=.8,g=.03,_=.97,v=0,y=0,b={x:0,y:0,zx:0,zy:0},x=0,S=new Float32Array(16),C=-1,w=new Float32Array(4);function T(){n.width=Math.round(innerWidth*u),n.height=Math.round(innerHeight*u),r.viewport(0,0,n.width,n.height)}T(),addEventListener(`resize`,T),addEventListener(`pointermove`,e=>{b.zx=e.clientX/innerWidth*2-1,b.zy=e.clientY/innerHeight*2-1},{passive:!0});function E(){let t=e.getBoundingClientRect();m=Math.max(.05,(t.left-70)/innerWidth),h=Math.min(.95,(t.right+70)/innerWidth),g=(innerWidth*.022+14)/innerWidth,_=1-g;let n=t.bottom+40;document.querySelectorAll(`.mg-fuss`).forEach(e=>{let t=e.getBoundingClientRect();t.height&&(n=Math.max(n,t.bottom))}),c.style.setProperty(`--tisch-y`,`${Math.round(Math.min(innerHeight-70,n-6))}px`),c.style.setProperty(`--monitor-l`,`${Math.round(t.left-70)}px`),c.style.setProperty(`--monitor-r`,`${Math.round(innerWidth-t.right-70)}px`)}let D=()=>g+(m-g)*.32;function O(){let e=v>.8,t=D()+(Math.random()-.5)*.01,n=f+(e?.012:.035);for(let e=0;e<8;e++)S[e*2]=t,S[e*2+1]=n,t+=(Math.random()-.5)*.01,n-=(n-.496)/(7-Math.min(e,6));let r=performance.now(),i=e=>{let t=(e-r)/1e3;x=t<.08?1:t<.16?.25:t<.24?.85:Math.max(0,.85-(t-.24)*2.5),x>0&&requestAnimationFrame(i)};requestAnimationFrame(i)}function k(){setTimeout(()=>{O(),k()},3e4+Math.random()*35e3)}k();function A(){w[0]=Math.random()<.5?g+(m-g)*(.3+Math.random()*.5):h+(_-h)*(.2+Math.random()*.5),w[1]=.8+Math.random()*.12;let e=-.6-Math.random()*.5;w[2]=Math.cos(e)*(Math.random()<.5?1:-1)*.7,w[3]=Math.sin(e),C=performance.now()}function j(){setTimeout(()=>{v>.8&&A(),j()},1e4+Math.random()*15e3)}j();let M=()=>{let e=document.documentElement.scrollHeight-innerHeight;return e>0?Math.min(1,Math.max(0,scrollY/e)):0};v=y=M(),addEventListener(`scroll`,()=>y=M(),{passive:!0});let N=performance.now(),P=0,F=0,I=()=>{cancelAnimationFrame(F),F=requestAnimationFrame(L)};document.addEventListener(`visibilitychange`,()=>{document.hidden?cancelAnimationFrame(F):I()});function L(e){if(F=requestAnimationFrame(L),e-P<32||!l.matches||c.classList.contains(`ak-offen`)||document.querySelector(`dialog[open]`))return;let a=Math.min(.5,(e-(P||e))/1e3);P=e,E(),v+=(y-v)*(1-Math.exp(-a/.25)),Math.abs(y-v)<.001&&(v=y),b.x+=(b.zx-b.x)*(1-Math.exp(-a/.6)),b.y+=(b.zy-b.y)*(1-Math.exp(-a/.6)),t.style.setProperty(`--licht`,String(Math.min(1,Math.max(.12,1-(v-.5)/.45)).toFixed(3)));let o=C<0?-1:(e-C)/900;o>1&&(C=-1);let s=r;s.uniform2f(i.uRes,n.width,n.height),s.uniform1f(i.uZeit,(e-N)/1e3),s.uniform1f(i.uTag,v),s.uniform2f(i.uMaus,b.x,b.y),s.uniform1f(i.uLinks,m),s.uniform1f(i.uRechts,h),s.uniform1f(i.uRahmenL,g),s.uniform1f(i.uRahmenR,_),s.uniform1f(i.uBlitz,x),s.uniform2fv(i.uBolt,S),s.uniform4fv(i.uStern,w),s.uniform1f(i.uSternT,o),s.drawArrays(s.TRIANGLES,0,3)}return I(),window.aussicht={get tag(){return v},get blitz(){return x},get sternschnuppe(){return C>=0},testBlitz:O,testSternschnuppe:A},!0}export{m as starteAussicht};